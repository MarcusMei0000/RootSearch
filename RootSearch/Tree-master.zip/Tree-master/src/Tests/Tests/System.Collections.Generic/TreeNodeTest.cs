﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

using NUnit.Framework;
using Tests.Data;


namespace Tests.System.Collections.Generic
{
	[TestFixture]
	public class TreeNodeTest
	{
		private DataProvider data = new DataProvider();
	}
}
