﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Linq;


namespace Tests.Data
{
	static class TreeParser
	{
		/*public static string Serialize(TreeNode node)
		{
			return null;
		}

		public static string Serialize<T>(TreeNode<T> node)
		{
			return null;
		}

		public static string Serialize(TreeNodeCollection nodes)
		{
			return null;
		}

		public static string Serialize<T>(TreeNodeCollection<T> nodes)
		{
			return null;
		}

		public static TreeNodeCollection Deserialize(string input)
		{
			return null;
		}

		public static TreeNodeCollection<T> Deserialize<T>(string input)
		{
			return null;
		}*/
	}
}
